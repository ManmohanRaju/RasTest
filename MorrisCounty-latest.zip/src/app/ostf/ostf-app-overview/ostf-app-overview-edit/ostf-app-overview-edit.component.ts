import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-overview-edit',
  templateUrl: './ostf-app-overview-edit.component.html',
  styleUrls: ['./ostf-app-overview-edit.component.scss']
})
export class OstfAppOverviewEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
