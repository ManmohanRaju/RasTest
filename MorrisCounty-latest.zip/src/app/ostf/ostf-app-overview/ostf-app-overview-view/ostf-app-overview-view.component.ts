import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-overview-view',
  templateUrl: './ostf-app-overview-view.component.html',
  styleUrls: ['./ostf-app-overview-view.component.scss']
})
export class OstfAppOverviewViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  fileChange(a){

  }
  onFileSelected(){
    
  }
}
