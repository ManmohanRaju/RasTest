import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-site-characteristics-edit',
  templateUrl: './ostf-app-site-characteristics-edit.component.html',
  styleUrls: ['./ostf-app-site-characteristics-edit.component.scss']
})
export class OstfAppSiteCharacteristicsEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
