import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-role-edit',
  templateUrl: './ostf-app-role-edit.component.html',
  styleUrls: ['./ostf-app-role-edit.component.scss']
})
export class OstfAppRoleEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
