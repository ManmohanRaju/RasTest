import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-signature-edit',
  templateUrl: './ostf-app-signature-edit.component.html',
  styleUrls: ['./ostf-app-signature-edit.component.scss']
})
export class OstfAppSignatureEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
