import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-signature-view',
  templateUrl: './ostf-app-signature-view.component.html',
  styleUrls: ['./ostf-app-signature-view.component.scss']
})
export class OstfAppSignatureViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  showImage(e){

  }
}
