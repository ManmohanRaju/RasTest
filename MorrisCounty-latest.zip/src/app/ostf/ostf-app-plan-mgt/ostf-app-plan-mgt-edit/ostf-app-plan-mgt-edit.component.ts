import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-plan-mgt-edit',
  templateUrl: './ostf-app-plan-mgt-edit.component.html',
  styleUrls: ['./ostf-app-plan-mgt-edit.component.scss']
})
export class OstfAppPlanMgtEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
