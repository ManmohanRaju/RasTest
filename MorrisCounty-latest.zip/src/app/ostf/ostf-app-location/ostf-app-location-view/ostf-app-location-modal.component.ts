import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-location-modal',
  templateUrl: './ostf-app-location-modal.component.html',
  styleUrls: ['./ostf-app-location-modal.component.scss']
})
export class OstfAppLocationModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
