import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-location-edit',
  templateUrl: './ostf-app-location-edit.component.html',
  styleUrls: ['./ostf-app-location-edit.component.scss']
})
export class OstfAppLocationEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
