import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-staff-info-view',
  templateUrl: './ostf-app-staff-info-view.component.html',
  styleUrls: ['./ostf-app-staff-info-view.component.scss']
})
export class OstfAppStaffInfoViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
