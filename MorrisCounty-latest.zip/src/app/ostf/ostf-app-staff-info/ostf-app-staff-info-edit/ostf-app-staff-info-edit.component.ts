import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-staff-info-edit',
  templateUrl: './ostf-app-staff-info-edit.component.html',
  styleUrls: ['./ostf-app-staff-info-edit.component.scss']
})
export class OstfAppStaffInfoEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
