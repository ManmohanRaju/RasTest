import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-preserved-edit',
  templateUrl: './ostf-app-preserved-edit.component.html',
  styleUrls: ['./ostf-app-preserved-edit.component.scss']
})
export class OstfAppPreservedEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
