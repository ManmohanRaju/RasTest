import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-pending-edit',
  templateUrl: './ostf-app-pending-edit.component.html',
  styleUrls: ['./ostf-app-pending-edit.component.scss']
})
export class OstfAppPendingEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
