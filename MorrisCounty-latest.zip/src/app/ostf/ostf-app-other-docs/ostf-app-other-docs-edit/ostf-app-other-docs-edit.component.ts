import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-other-docs-edit',
  templateUrl: './ostf-app-other-docs-edit.component.html',
  styleUrls: ['./ostf-app-other-docs-edit.component.scss']
})
export class OstfAppOtherDocsEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
