import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-project-edit',
  templateUrl: './ostf-app-project-edit.component.html',
  styleUrls: ['./ostf-app-project-edit.component.scss']
})
export class OstfAppProjectEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
