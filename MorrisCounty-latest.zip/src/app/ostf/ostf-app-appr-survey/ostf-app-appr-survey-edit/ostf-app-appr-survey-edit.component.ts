import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-appr-survey-edit',
  templateUrl: './ostf-app-appr-survey-edit.component.html',
  styleUrls: ['./ostf-app-appr-survey-edit.component.scss']
})
export class OstfAppApprSurveyEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
