import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-admin-closing-view',
  templateUrl: './ostf-app-admin-closing-view.component.html',
  styleUrls: ['./ostf-app-admin-closing-view.component.scss']
})
export class OstfAppAdminClosingViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
