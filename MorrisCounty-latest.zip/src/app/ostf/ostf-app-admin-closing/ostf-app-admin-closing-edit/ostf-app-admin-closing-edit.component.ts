import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-admin-closing-edit',
  templateUrl: './ostf-app-admin-closing-edit.component.html',
  styleUrls: ['./ostf-app-admin-closing-edit.component.scss']
})
export class OstfAppAdminClosingEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
