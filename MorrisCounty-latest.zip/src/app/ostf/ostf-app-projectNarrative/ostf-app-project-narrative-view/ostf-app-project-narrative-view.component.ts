import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-project-narrative-view',
  templateUrl: './ostf-app-project-narrative-view.component.html',
  styleUrls: ['./ostf-app-project-narrative-view.component.scss']
})
export class OstfAppProjectNarrativeViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
