import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-project-narrative-edit',
  templateUrl: './ostf-app-project-narrative-edit.component.html',
  styleUrls: ['./ostf-app-project-narrative-edit.component.scss']
})
export class OstfAppProjectNarrativeEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
