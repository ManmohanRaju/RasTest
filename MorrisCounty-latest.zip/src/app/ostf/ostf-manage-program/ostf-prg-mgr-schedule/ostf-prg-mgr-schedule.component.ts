import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-prg-mgr-schedule',
  templateUrl: './ostf-prg-mgr-schedule.component.html',
  styleUrls: ['./ostf-prg-mgr-schedule.component.scss']
})
export class OstfPrgMgrScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
