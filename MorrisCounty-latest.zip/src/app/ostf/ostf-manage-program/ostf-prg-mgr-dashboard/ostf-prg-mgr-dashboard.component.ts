import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-prg-mgr-dashboard',
  templateUrl: './ostf-prg-mgr-dashboard.component.html',
  styleUrls: ['./ostf-prg-mgr-dashboard.component.scss']
})
export class OstfPrgMgrDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
