import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-prg-mgr-parcels',
  templateUrl: './ostf-prg-mgr-parcels.component.html',
  styleUrls: ['./ostf-prg-mgr-parcels.component.scss']
})
export class OstfPrgMgrParcelsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
