import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-prg-mgr-email-templates',
  templateUrl: './ostf-prg-mgr-email-templates.component.html',
  styleUrls: ['./ostf-prg-mgr-email-templates.component.scss']
})
export class OstfPrgMgrEmailTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
