import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-prg-mgr-users',
  templateUrl: './ostf-prg-mgr-users.component.html',
  styleUrls: ['./ostf-prg-mgr-users.component.scss']
})
export class OstfPrgMgrUsersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
