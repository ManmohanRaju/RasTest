import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-breadcrumb',
  templateUrl: './ostf-app-breadcrumb.component.html',
  styleUrls: ['./ostf-app-breadcrumb.component.scss']
})
export class OstfAppBreadcrumbComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
