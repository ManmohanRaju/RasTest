import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ostf-app-admin-pending-edit',
  templateUrl: './ostf-app-admin-pending-edit.component.html',
  styleUrls: ['./ostf-app-admin-pending-edit.component.scss']
})
export class OstfAppAdminPendingEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
